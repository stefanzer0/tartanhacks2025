import json
import requests

# Load WhatsMyName JSON data
with open("wmn-data.json", "r", encoding="utf-8") as file:
    services = json.load(file)

def check_username(username):
    results = {}
    for service in services["sites"]:
        url = service["uri_check"].replace("{account}", username)
        try:
            response = requests.get(url, timeout=5)
            if response.status_code == service["e_code"]:
                results[service["name"]] = url  # Found a valid profile
        except requests.exceptions.RequestException:
            continue  # Skip timeouts/errors
    
    return results if results else {"status": "No accounts found"}

# Example usage
if __name__ == "__main__":
    username = input("Enter username to search: ")
    result = check_username(username)
    print(json.dumps(result, indent=2))
