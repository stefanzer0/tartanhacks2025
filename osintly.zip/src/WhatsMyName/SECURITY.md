# Security Policy

## Reporting a Vulnerability

To report a vulnerability, please create an [Issue](https://github.com/WebBreacher/WhatsMyName/issues) in this project or send an email to `micah` `@` `myosint.training`
